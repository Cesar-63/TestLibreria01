package com.testlibreria.resttest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
